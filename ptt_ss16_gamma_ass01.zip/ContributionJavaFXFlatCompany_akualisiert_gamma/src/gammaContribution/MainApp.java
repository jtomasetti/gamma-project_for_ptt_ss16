package gammaContribution;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.prefs.Preferences;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import gammaContribution.model.Employee;
import gammaContribution.model.EmployeeListWrapper;
import gammaContribution.model.HistoryEntry;
import gammaContribution.model.HistoryEntryWrapper;
import gammaContribution.view.EmployeeEditDialogController;
import gammaContribution.view.EmployeeOverviewController;
import gammaContribution.view.HistoryStatisticsController;
import gammaContribution.view.RootLayoutController;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class MainApp extends Application {

    private Stage primaryStage;
    private BorderPane rootLayout;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Flat Company");

        initRootLayout();

        showPersonOverview();
    }

    /**
     * Initializes the root layout.
     */
    public void initRootLayout() {
        try {
            // Load root layout from fxml file.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class
                    .getResource("view/RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();

            // Show the scene containing the root layout.
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);

            // Give the controller access to the main app.
            RootLayoutController controller = loader.getController();
            controller.setMainApp(this);

            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Try to load last opened person file.
        File file = getPersonFilePath();
        if (file != null) {
            loadPersonDataFromFile(file);
        }
        
        
    }

    /**
     * Shows the person overview inside the root layout.
     */
    /**
     * Shows the person overview inside the root layout.
     */
    public void showPersonOverview() {
        try {
            // Load person overview.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/EmployeeOverview.fxml"));
            AnchorPane personOverview = (AnchorPane) loader.load();

            // Set person overview into the center of root layout.
            rootLayout.setCenter(personOverview);

            // Give the controller access to the main app.
            EmployeeOverviewController controller = loader.getController();
            controller.setMainApp(this);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Returns the main stage.
     * @return
     */
    public Stage getPrimaryStage() {
        return primaryStage;
    }

    public static void main(String[] args) {
    	launch(args);
    }

    /**
     * The data as an observable list of Persons.
     */
    public ObservableList<Employee> employeeData = FXCollections.observableArrayList();
    public ObservableList<Employee> savedData = FXCollections.observableArrayList();
    public ObservableList<HistoryEntry> historydata = FXCollections.observableArrayList();
  
	/**
     * Constructor
     */
    public MainApp() {
        // Add some sample data
    	employeeData.add(new Employee("Hans", "Muster"));
    	employeeData.add(new Employee("Ruth", "Mueller"));
    	employeeData.add(new Employee("Heinz", "Kurz"));
    	employeeData.add(new Employee("Cornelia", "Meier"));
    	employeeData.add(new Employee("Werner", "Meyer"));
    	employeeData.add(new Employee("Lydia", "Kunz"));
    	employeeData.add(new Employee("Anna", "Best"));
    	employeeData.add(new Employee("Stefan", "Meier"));
        employeeData.add(new Employee("Martin", "Mueller"));
        setSavedData(getPersonData());
        historydata.add(new HistoryEntry(0,2016,30000, 2000));
        historydata.add(new HistoryEntry(1,2016,20000, 3000));
        historydata.add(new HistoryEntry(2,2016,40000, 5000));
        historydata.add(new HistoryEntry(3,2016,10000, 1000));
    }

    /**
     * Returns the data as an observable list of Persons.
     * @return
     */
    
    
    public ObservableList<Employee> getPersonData() {
        return employeeData;
    }
    public ObservableList<Employee> getSavedData() {
        return savedData;
    }
    public void setSavedData(ObservableList<Employee> list){
    	savedData.clear();
    	int i=0;
    	Employee emp;
    	while(i<list.size()) {
    		emp = new Employee(list.get(i));
    		i++;
    		savedData.add(emp);
    	}
    }
    
    
    public void setPersonData(ObservableList<Employee> list) {
    	employeeData.clear();
    	int i=0;
    	Employee emp;
    	while(i<list.size()) {
    		emp = new Employee(list.get(i));
    		i++;
    		employeeData.add(emp);
    	}
    }

    public void restorePersonData(ObservableList<Employee> list) {
    	this.setPersonData(list);
    }
    
    
    
    /**
     * Opens a dialog to edit details for the specified person. If the user
     * clicks OK, the changes are saved into the provided person object and true
     * is returned.
     *
     * @param person the person object to be edited
     * @return true if the user clicked OK, false otherwise.
     */
    public boolean showPersonEditDialog(Employee person) {
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/EmployeeEditDialog.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Edit Person");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            // Set the person into the controller.
            EmployeeEditDialogController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setPerson(person);

            // Show the dialog and wait until the user closes it
            dialogStage.showAndWait();

            return controller.isOkClicked();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Returns the person file preference, i.e. the file that was last opened.
     * The preference is read from the OS specific registry. If no such
     * preference can be found, null is returned.
     *
     * @return
     */
    public File getPersonFilePath() {
        Preferences prefs = Preferences.userNodeForPackage(MainApp.class);
        String filePath = prefs.get("filePath", null);
        if (filePath != null) {
            return new File(filePath);
        } else {
            return null;
        }
    }
    
    public File getHistoryFilePath() {
    	Preferences prefs = Preferences.userNodeForPackage(MainApp.class);
    	String filePath = prefs.get("filePath", null);
    	if( filePath != null) {
    		return new File(filePath);
    	} else {
    		return null;
    	}
    }

    /**
     * Sets the file path of the currently loaded file. The path is persisted in
     * the OS specific registry.
     *
     * @param file the file or null to remove the path
     */
    public void setPersonFilePath(File file) {
        Preferences prefs = Preferences.userNodeForPackage(MainApp.class);
        if (file != null) {
            prefs.put("filePath", file.getPath());

            // Update the stage title.
            primaryStage.setTitle("Contribution - " + file.getName());
        } else {
            prefs.remove("filePath");

            // Update the stage title.
            primaryStage.setTitle("Contribution");
        }
    }

    /**
     * Loads person data from the specified file. The current person data will
     * be replaced.
     *
     * @param file
     */
    public void loadPersonDataFromFile(File file) {
        try {
            JAXBContext context = JAXBContext
                    .newInstance(EmployeeListWrapper.class);
            Unmarshaller um = context.createUnmarshaller();

            // Reading XML from the file and unmarshalling.
            EmployeeListWrapper wrapper = (EmployeeListWrapper) um.unmarshal(file);
            employeeData.clear();
            employeeData.addAll(wrapper.getPersons());
     //       historydata.clear();
     //       historydata.addAll(wrapper.getEntrys());

            // Save the file path to the registry.
            setPersonFilePath(file);

        } catch (Exception e) { // catches ANY exception
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Could not load data");
            alert.setContentText("Could not load data from file:\n" + file.getPath());

            alert.showAndWait();
        }
    }
    
/*    public void loadHistoryDataFromFile(File file) {
    	try {
            JAXBContext context = JAXBContext
                    .newInstance(HistoryEntryWrapper.class);
            Unmarshaller um = context.createUnmarshaller();

            // Reading XML from the file and unmarshalling.
            HistoryEntryWrapper wrapper = (HistoryEntryWrapper) um.unmarshal(file);

            historydata.clear();
            historydata.addAll(wrapper.getEntrys());

            // Save the file path to the registry.
            setPersonFilePath(file);

        } catch (Exception e) { // catches ANY exception
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Could not load data");
            alert.setContentText("Could not load data from file:\n" + file.getPath());

            alert.showAndWait();
        }
    }
*/
    /**
     * Saves the current person data to the specified file.
     *
     * @param file
     */
    public void savePersonDataToFile(File file) {
        try {
            JAXBContext context = JAXBContext
                    .newInstance(EmployeeListWrapper.class);
            Marshaller m = context.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            // Wrapping our person data.
            EmployeeListWrapper wrapper = new EmployeeListWrapper();
            wrapper.setPersons(employeeData);
            

            // Marshalling and saving XML to the file.
            m.marshal(wrapper, file);

            // Save the file path to the registry.
            setPersonFilePath(file);
        } catch (Exception e) { // catches ANY exception
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Could not save data");
            alert.setContentText("Could not save data to file:\n" + file.getPath());

            alert.showAndWait();
        }
    }
 /*   public void saveHistoryDataToFile(File file) {
        try {
            JAXBContext context = JAXBContext
                    .newInstance(HistoryEntryWrapper.class);
            Marshaller m = context.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            // Wrapping our person data.
            HistoryEntryWrapper wrapper = new HistoryEntryWrapper();
            wrapper.setHistory(historydata);

            // Marshalling and saving XML to the file.
            m.marshal(wrapper, file);

            // Save the file path to the registry.
            setHistoryFilePath(file);
        } catch (Exception e) { // catches ANY exception
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Could not save data");
            alert.setContentText("Could not save data to file:\n" + file.getPath());

            alert.showAndWait();
        }
    }
 */   
    private void setHistoryFilePath(File file) {
		Preferences prefs = Preferences.userNodeForPackage(MainApp.class);
        if (file != null) {
            prefs.put("filePath", file.getPath());

            // Update the stage title.
            primaryStage.setTitle("Contribution - " + file.getName());
        } else {
            prefs.remove("filePath");

            // Update the stage title.
            primaryStage.setTitle("Contribution");
        }
	}

	/**
     * Opens a dialog to show birthday statistics.
     */
    public void showHistory() {
        try {
            // Load the fxml file and create a new stage for the popup.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/HistoryStatistics.fxml"));
            AnchorPane page = (AnchorPane) loader.load();
            Stage dialogStage = new Stage();
            dialogStage.setTitle("History Statistics");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            // Set the persons into the controller.
            HistoryStatisticsController controller = loader.getController();
            
            //falls Firma leer abfangen
            if (employeeData.size()==0) {
            	Alert alert = new Alert(AlertType.ERROR);
            	alert.setTitle("Error");
            	alert.setHeaderText("Could not show statistics for empty company");
            	alert.setContentText("Could not show statistics for empty company");

            	alert.showAndWait();
            } else {
          //total berechnung
    		double total = 0; int i=0;
        	List<Employee> employeeList = employeeData;
        	int max = employeeList.size();
        	while(i<max) {
        		total += employeeList.get(i).getSalary();
        		i++;
        	}
        	//median Berechnung
        	ObservableList<Employee> unsort = FXCollections.observableArrayList();
        	EmployeeListWrapper wrapper = new EmployeeListWrapper();
            wrapper.setPersons(employeeData);
         	unsort.clear();
        	unsort.addAll(wrapper.getPersons());
        	int n = employeeList.size();double median;
        	
        	quicksort(0,n-1,employeeList); // sortiert die Employee-Daten
        	
        	if(n%2==0) {
        		median = (employeeList.get(n/2).getSalary()+employeeList.get((n/2)-1).getSalary())/2; 
        	} else {
        		median = employeeList.get((n/2)).getSalary();
        	}
        	wrapper = new EmployeeListWrapper();
            wrapper.setPersons(unsort);
            employeeData.clear();
        	employeeData.addAll(wrapper.getPersons());
            
            Date dt = new Date();
            if(historydata.size()==0) {
            	HistoryEntry he = new HistoryEntry(dt.getMonth(),dt.getYear(), total, median);
            	historydata.add(he);
            	
            } else if(historydata.get(historydata.size()-1).getMonth()==dt.getMonth() && historydata.get(historydata.size()-1).getYear()==dt.getYear()){
            	
            } else {
            	@SuppressWarnings("deprecation")
				HistoryEntry he = new HistoryEntry(dt.getMonth(),dt.getYear(), total, median);
            	historydata.add(he);
            }
            controller.setHistoryData(employeeData, historydata);
        	dialogStage.show();
            }
            } catch (IOException e) {
        		e.printStackTrace();
        	}
    }
    
    void quicksort(int left,int right,List<Employee> employeeList) {
    	int i = left, j = right;
    	double pivot = employeeList.get(left+(right-left)/2).getSalary();
    	while(i<=j) {
    		while(employeeList.get(i).getSalary()<pivot) {
    			i++;
    		}
    		while(employeeList.get(j).getSalary()>pivot) {
    			j--;
    		}
    		if(i<=j){
    			exchange(i,j,employeeList); i++; j--;
    		}
    	}
    	if( left < j) {
    		quicksort( left, j ,employeeList);
    	}
    	if( i < right) {
    		quicksort(i, right, employeeList);
    	}
    }   
    
    private void exchange(int i, int j,List<Employee> employeeList) {
    	Employee temp = employeeList.get(i);
    	employeeList.set(i,employeeList.get(j)); 
    	employeeList.set(j,temp);
	}

	public ObservableList<HistoryEntry> getHistoryData() {
		
		return this.historydata;
	}
    
}