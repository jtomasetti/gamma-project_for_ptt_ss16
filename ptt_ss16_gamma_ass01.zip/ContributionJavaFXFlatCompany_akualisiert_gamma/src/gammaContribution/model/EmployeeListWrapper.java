package gammaContribution.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import javafx.collections.ObservableList;

/**
 * Helper class to wrap a list of persons. This is used for saving the
 * list of persons to XML.
 * 
 * @author Marco Jakob
 */
@XmlRootElement(name = "data")
public class EmployeeListWrapper {

    private List<Employee> persons;

    @XmlElement(name = "person")
    public List<Employee> getPersons() {
        return persons;
    }

    public void setPersons(List<Employee> persons) {
        this.persons = persons;
    }
    
   
}