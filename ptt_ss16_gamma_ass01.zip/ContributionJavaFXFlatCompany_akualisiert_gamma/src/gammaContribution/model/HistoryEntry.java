package gammaContribution.model;

public class HistoryEntry {
	int month;
	int year;
	double total;
	double median;
	
	
	public HistoryEntry(int mo,int y,double t, double m) {
		this.month=mo;
		this.year=y;
		this.total=t;
		this.median=m;
	}
	
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public double getMedian() {
		return median;
	}
	public void setMedian(double median) {
		this.median = median;
	}

}
