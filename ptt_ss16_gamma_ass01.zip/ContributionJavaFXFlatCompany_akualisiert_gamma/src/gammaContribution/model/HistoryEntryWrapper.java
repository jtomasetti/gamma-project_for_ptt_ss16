package gammaContribution.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import javafx.collections.ObservableList;

@XmlRootElement(name = "historyEntrys")
public class HistoryEntryWrapper {

    private List<HistoryEntry> historyData;

    @XmlElement(name = "historyEntry")
    public List<HistoryEntry> getEntrys() {
        return historyData;
    }

    public void setEntry(List<HistoryEntry> h) {
        this.historyData = h;
    }

	public void setHistory(ObservableList<HistoryEntry> historydata2) {
		this.historyData = historydata2;
	}
}