package gammaContribution.view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.util.Iterator;

import gammaContribution.MainApp;
import gammaContribution.model.Employee;
import gammaContribution.model.EmployeeListWrapper;
import gammaContribution.util.DateUtil;

public class EmployeeOverviewController {
    @FXML
    private TableView<Employee> personTable;
    @FXML
    private TableColumn<Employee, String> firstNameColumn;
    @FXML
    private TableColumn<Employee, String> lastNameColumn;

    @FXML
    private Label firstNameLabel;
    @FXML
    private Label lastNameLabel;
    @FXML
    private Label streetLabel;
    @FXML
    private Label postalCodeLabel;
    @FXML
    private Label cityLabel;
    @FXML
    private Label birthdayLabel;
    @FXML
    private Label salaryLabel;
    
    @FXML
    private Label totalLabel;
    @FXML
    private Label medianLabel;

    // Reference to the main application.
    private MainApp mainApp;   
    
    //ObservableList<Person> employeeList = mainApp.getPersonData();

	/**
     * The constructor.
     * The constructor is called before the initialize() method.
     */
    public EmployeeOverviewController() {
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        // Initialize the person table with the two columns.
        firstNameColumn.setCellValueFactory(
                cellData -> cellData.getValue().firstNameProperty());
        lastNameColumn.setCellValueFactory(
                cellData -> cellData.getValue().lastNameProperty());

        // Clear person details.
        showPersonDetails(null);

        // Listen for selection changes and show the person details when changed.
        personTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> showPersonDetails(newValue));
   
    }

    /**
     * Is called by the main application to give a reference back to itself.
     * 
     * @param mainApp
     */
    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;

        // Add observable list data to the table
        personTable.setItems(mainApp.getPersonData());
    }
    
    /**
     * Fills all text fields to show details about the person.
     * If the specified person is null, all text fields are cleared.
     * 
     * @param person the person or null
     */
    private void showPersonDetails(Employee person) {
        if (person != null) {
            // Fill the labels with info from the person object.
            firstNameLabel.setText(person.getFirstName());
            lastNameLabel.setText(person.getLastName());
            streetLabel.setText(person.getStreet());
            postalCodeLabel.setText(Integer.toString(person.getPostalCode()));
            cityLabel.setText(person.getCity());
            birthdayLabel.setText(DateUtil.format(person.getBirthday()));
            salaryLabel.setText(Double.toString(person.getSalary()));
        } else {
            // Person is null, remove all the text.
            firstNameLabel.setText("");
            lastNameLabel.setText("");
            streetLabel.setText("");
            postalCodeLabel.setText("");
            cityLabel.setText("");
            birthdayLabel.setText("");
            salaryLabel.setText("");
            
        }
    }
    

    @FXML
    private void handleDeletePerson() {
    	mainApp.setSavedData(mainApp.getPersonData());
    	    	
        int selectedIndex = personTable.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            personTable.getItems().remove(selectedIndex);
        } else {
            // Nothing selected.
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No Selection");
            alert.setHeaderText("No Person Selected");
            alert.setContentText("Please select a person in the table.");

            alert.showAndWait();
        }
    }
    /**
     * Called when the user clicks the new button. Opens a dialog to edit
     * details for a new person.
     */
    @FXML
    private void handleNewPerson() {
    	// save State
    	mainApp.setSavedData(mainApp.getPersonData());
    	
        Employee tempPerson = new Employee();
        boolean okClicked = mainApp.showPersonEditDialog(tempPerson);
        if (okClicked) {
            mainApp.getPersonData().add(tempPerson);
        }
    }

    /**
     * Called when the user clicks the edit button. Opens a dialog to edit
     * details for the selected person.
     */
   // boolean lastEdit;
    @FXML
    private void handleEditPerson() {
    	
        Employee selectedPerson = personTable.getSelectionModel().getSelectedItem();
        if (selectedPerson != null) {
        	// save State
        	mainApp.setSavedData(mainApp.getPersonData());
    		boolean okClicked = mainApp.showPersonEditDialog(selectedPerson);
            if (okClicked) {
                showPersonDetails(selectedPerson);
            }
        } else {
            // Nothing selected.
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No Selection");
            alert.setHeaderText("No Person Selected");
            alert.setContentText("Please select a person in the table.");

            alert.showAndWait();
        }
    }
    
    @FXML
    private void handleTotal() {
    	
    	double total = 0; int i=0;
    	ObservableList<Employee> employeeList = mainApp.getPersonData();
    	int max = employeeList.size();
    	while(i<max) {
    		total += employeeList.get(i).getSalary();
    		i++;
    	}
    	totalLabel.setText(Double.toString(total));
    }
//    boolean lastCut;
    
    @FXML
    private void handleCut() {
    	
    	mainApp.setSavedData(mainApp.getPersonData());
    	
    	ObservableList<Employee> employeeList = mainApp.getPersonData();
    	Iterator<Employee> iter = employeeList.iterator();
    	Employee employee = iter.next();
    	
    	while(employee != null) {
    		employee.setSalary(employee.getSalary()/2);
    		employee = iter.next();
    	}    	
    	
    } 
       
    @FXML
    private void handleMedian() {
    	ObservableList<Employee> unsort = FXCollections.observableArrayList();
    	ObservableList<Employee> employeeList= mainApp.getPersonData();
    	EmployeeListWrapper wrapper = new EmployeeListWrapper();
        wrapper.setPersons(mainApp.getPersonData());
     	unsort.clear();
    	unsort.addAll(wrapper.getPersons());
    	int n = employeeList.size();double median;
    	
    	quicksort(0,n-1,employeeList); // sortiert die Employee-Daten
    	
    	if(n%2==0) {
    		median = (employeeList.get(n/2).getSalary()+employeeList.get((n/2)-1).getSalary())/2; 
    	} else {
    		median = employeeList.get((n/2)).getSalary();
    	}
    	wrapper = new EmployeeListWrapper();
        wrapper.setPersons(unsort);
     	mainApp.employeeData.clear();
    	mainApp.employeeData.addAll(wrapper.getPersons());
    	medianLabel.setText(Double.toString(median));
    }
   /* @FXML
    private void handleMedian() {
    	ObservableList<Employee> employeeList= mainApp.getPersonData();
    	int n = employeeList.size();int median;
    	
    	quicksort(0,n-1,employeeList); // sortiert die Employee-Daten
    	
    	if(n%2==0) {
    		median = (employeeList.get(n/2).getSalary()+employeeList.get((n/2)-1).getSalary())/2; 
    	} else {
    		median = employeeList.get((n/2)).getSalary();
    	}
    	
    	medianLabel.setText(Integer.toString(median));
    }
    */
    void quicksort(int left,int right,ObservableList<Employee> employeeList) {
    	int i = left, j = right;
    	double pivot = employeeList.get(left+(right-left)/2).getSalary();
    	while(i<=j) {
    		while(employeeList.get(i).getSalary()<pivot) {
    			i++;
    		}
    		while(employeeList.get(j).getSalary()>pivot) {
    			j--;
    		}
    		if(i<=j){
    			exchange(i,j,employeeList); i++; j--;
    		}
    	}
    	if( left < j) {
    		quicksort( left, j ,employeeList);
    	}
    	if( i < right) {
    		quicksort(i, right, employeeList);
    	}
    }    
    private void exchange(int i, int j,ObservableList<Employee> employeeList) {
    	Employee temp = employeeList.get(i);
    	employeeList.set(i,employeeList.get(j)); 
    	employeeList.set(j,temp);
	}
    
/*    private void reverseCut() {
    	//save State
    	ObservableList<Employee> employeeList = mainApp.getPersonData();
    	Iterator<Employee> iter = employeeList.iterator();
    	Employee employee = iter.next();
    	lastCut = false;
    	while(employee != null) {
    		employee.setSalary(employee.getSalary()*2);
    		employee = iter.next();
    	}
    	
    } */ 
    
    @FXML
    private void undo() {
    		mainApp.restorePersonData(mainApp.getSavedData());    	
    }
    
    @FXML
    private void history() {
    	
    }
}