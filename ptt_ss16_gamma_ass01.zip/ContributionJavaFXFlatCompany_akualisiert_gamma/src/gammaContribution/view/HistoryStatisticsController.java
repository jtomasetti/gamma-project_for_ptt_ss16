package gammaContribution.view;

import java.text.DateFormatSymbols;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import gammaContribution.model.Employee;
import gammaContribution.model.HistoryEntry;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;

public class HistoryStatisticsController {
	@FXML
	private LineChart<String, Double> LineChart;
	
	@FXML
	private CategoryAxis xAxis;
	
	private ObservableList<String> monthNames = 
			FXCollections.observableArrayList();
	
	
		
	@FXML
    private void initialize() {
        
        String[] months = DateFormatSymbols.getInstance(Locale.ENGLISH).getMonths();
        
        monthNames.addAll(Arrays.asList(months));

        xAxis.setCategories(monthNames);
    }
	
	
	@SuppressWarnings({ "unchecked"})
	public void setHistoryData(List<Employee> employees,
			ObservableList<HistoryEntry> historydata ) {
        
		
   
        XYChart.Series<String, Double> series = new XYChart.Series<>();
        series.setName("median");
        XYChart.Series<String, Double> series2 = new XYChart.Series<>();
        series2.setName("total");

        
        
        for(int i=0; i<historydata.size(); i++) {
        	int j= historydata.get(i).getMonth();
        	double median = historydata.get(i).getMedian();
        	double total = historydata.get(i).getTotal();
        	series.getData().add(new XYChart.Data<>(monthNames.get(j), median));
        	series2.getData().add(new XYChart.Data<>(monthNames.get(j), total));
        }
        
        LineChart.getData().addAll(series, series2);
    }
	
    	
    
    
    
}
